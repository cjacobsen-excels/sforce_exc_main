<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>SAL.CPNEA3</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Advisor</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Student has accepted date for 3rd and final CPNE attempt. Review file for any remaining gen. ed. needed, then CALL STUDENT to ask how they&apos;ve been preparing, and to encourage use of all available CPNE prep resources.</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:double">4.0</value>
    </values>
    <values>
        <field>Priority__c</field>
        <value xsi:type="xsd:string">High</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">CPNE 3rd Attempt Outreach</value>
    </values>
</CustomMetadata>
