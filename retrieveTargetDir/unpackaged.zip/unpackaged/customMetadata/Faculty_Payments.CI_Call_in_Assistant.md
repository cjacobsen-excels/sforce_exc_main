<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CI Call-in Assistant</label>
    <protected>false</protected>
    <values>
        <field>Additional_Pay__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Course_Type__c</field>
        <value xsi:type="xsd:string">Clinical Instructor On Call</value>
    </values>
    <values>
        <field>Credits__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Faculty_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Fee_Type__c</field>
        <value xsi:type="xsd:string">Per</value>
    </values>
    <values>
        <field>Flat_Fee__c</field>
        <value xsi:type="xsd:double">31.25</value>
    </values>
    <values>
        <field>Level__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Lower_Range_Enrollment__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Upper_Range_Enrollment__c</field>
        <value xsi:nil="true"/>
    </values>
</CustomMetadata>
