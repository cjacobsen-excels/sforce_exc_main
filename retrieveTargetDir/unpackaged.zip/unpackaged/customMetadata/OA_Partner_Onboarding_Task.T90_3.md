<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>T90.3</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To_Id__c</field>
        <value xsi:type="xsd:string">005U0000002dApHIAU</value>
    </values>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Kailey Soundara</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Draft President&apos;s Letter and send to President Office for approval.</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:string">1 Day after Stage changes to 90 - Commitment Written</value>
    </values>
    <values>
        <field>Skip_for_CEP__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">POP.Draft President&apos;s Letter</value>
    </values>
    <values>
        <field>Type__c</field>
        <value xsi:type="xsd:string">Email</value>
    </values>
</CustomMetadata>
