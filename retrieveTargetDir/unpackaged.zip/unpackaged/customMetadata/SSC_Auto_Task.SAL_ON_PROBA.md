<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>SAL.ON_PROBA</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Advisor</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Contact student regarding probation status</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:double">5.0</value>
    </values>
    <values>
        <field>Priority__c</field>
        <value xsi:type="xsd:string">Normal</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">Initial Probation Outreach</value>
    </values>
</CustomMetadata>
