<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>SAL.NSLA2</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Advisor</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Student is taking NSL+PCS for Phase IV and has accepted a date for NSL. Please reach out to see how preparation is going, and send follow-up email about preparation resources.</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:double">2.0</value>
    </values>
    <values>
        <field>Priority__c</field>
        <value xsi:type="xsd:string">High</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">NSL/PCS Prep Outreach</value>
    </values>
</CustomMetadata>
