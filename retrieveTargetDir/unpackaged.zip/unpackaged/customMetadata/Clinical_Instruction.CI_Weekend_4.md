<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CI Weekend 4</label>
    <protected>false</protected>
    <values>
        <field>Weekend_Begins__c</field>
        <value xsi:type="xsd:double">46.0</value>
    </values>
    <values>
        <field>Weekend_Ends__c</field>
        <value xsi:type="xsd:double">48.0</value>
    </values>
    <values>
        <field>Weekend__c</field>
        <value xsi:type="xsd:string">Make-up</value>
    </values>
</CustomMetadata>
