<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Main Setting</label>
    <protected>false</protected>
    <values>
        <field>Marketo_Notification_Template__c</field>
        <value xsi:type="xsd:string">Marketo_Log_Template</value>
    </values>
    <values>
        <field>Notifications_On__c</field>
        <value xsi:type="xsd:string">Fail</value>
    </values>
    <values>
        <field>Number_Of_Retries__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>Start_Date__c</field>
        <value xsi:type="xsd:date">2021-02-13</value>
    </values>
    <values>
        <field>When_to_Clear_Logs__c</field>
        <value xsi:type="xsd:double">10.0</value>
    </values>
    <values>
        <field>Who_Should_be_notified__c</field>
        <value xsi:type="xsd:string">eusalesforce@excelsior.edu</value>
    </values>
</CustomMetadata>
