<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>SAL.CPNECONFPK</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Advisor</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Student has a CPNE date; received auto-email from you recently. CALL STUDENT to follow up: encourage student to use prep resources listed in auto-email, to contact you w/ time management/study plan questions, and to contact SON w/ CPNE content questions.</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:double">7.0</value>
    </values>
    <values>
        <field>Priority__c</field>
        <value xsi:type="xsd:string">High</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">CPNE Prep Outreach</value>
    </values>
</CustomMetadata>
