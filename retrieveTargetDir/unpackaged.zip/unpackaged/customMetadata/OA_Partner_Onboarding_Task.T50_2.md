<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>T50.2</label>
    <protected>false</protected>
    <values>
        <field>Assigned_To_Id__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Assigned_To__c</field>
        <value xsi:type="xsd:string">Opportunity Owner</value>
    </values>
    <values>
        <field>Comments__c</field>
        <value xsi:type="xsd:string">Send final draft of agreement to Legal.</value>
    </values>
    <values>
        <field>Due_Date__c</field>
        <value xsi:type="xsd:string">1 Day after Stage changes to 50 - Negotiation</value>
    </values>
    <values>
        <field>Skip_for_CEP__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Subject__c</field>
        <value xsi:type="xsd:string">POP.Send final agreement draft to Legal for signature</value>
    </values>
    <values>
        <field>Type__c</field>
        <value xsi:type="xsd:string">Other</value>
    </values>
</CustomMetadata>
