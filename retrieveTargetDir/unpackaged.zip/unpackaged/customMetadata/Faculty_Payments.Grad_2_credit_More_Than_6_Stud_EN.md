<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Grad 2 credit More Than 6 Stud EN</label>
    <protected>false</protected>
    <values>
        <field>Additional_Pay__c</field>
        <value xsi:type="xsd:double">1000.0</value>
    </values>
    <values>
        <field>Course_Type__c</field>
        <value xsi:type="xsd:string">Enhanced Pay</value>
    </values>
    <values>
        <field>Credits__c</field>
        <value xsi:type="xsd:string">2</value>
    </values>
    <values>
        <field>Faculty_Type__c</field>
        <value xsi:type="xsd:string">Standard</value>
    </values>
    <values>
        <field>Fee_Type__c</field>
        <value xsi:type="xsd:string">Flat</value>
    </values>
    <values>
        <field>Flat_Fee__c</field>
        <value xsi:type="xsd:double">2000.0</value>
    </values>
    <values>
        <field>Level__c</field>
        <value xsi:type="xsd:string">Graduate</value>
    </values>
    <values>
        <field>Lower_Range_Enrollment__c</field>
        <value xsi:type="xsd:double">7.0</value>
    </values>
    <values>
        <field>Upper_Range_Enrollment__c</field>
        <value xsi:type="xsd:double">100.0</value>
    </values>
</CustomMetadata>
